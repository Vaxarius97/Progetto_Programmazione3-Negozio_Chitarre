package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

//Codice per creazione e ripristino del Database. Tabella Pagamento.
public class Pagamento {
	
	public static void insert() {
		Connection c = null;
		Statement stmt = null;

		try {
			//Collegamento del JDBC con il DataBase SQLite.
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");

			//Statement per l'isenrimento delle tuple.
			stmt = c.createStatement();
			String sql = "INSERT OR REPLACE INTO Pagamento (Codicepagamento,prezzotot,datapagamento)"
					+ "VALUES('pag1',600,'27/11/2019');";
			stmt.executeUpdate(sql);

			sql = "INSERT OR REPLACE INTO Pagamento (Codicepagamento,prezzotot,datapagamento)" + "VALUES('pag2',900,'11/12/2019');";
			stmt.executeUpdate(sql);

			

			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Records created successfully");

	}

	public static void create() {
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			System.out.println("Opened database successfully");

			//Statement per rimozione e ricreazione della tabella. 
			stmt = c.createStatement();
			
			String sql ="Drop table Pagamento;"+"CREATE TABLE IF NOT EXISTS Pagamento " + "(Codicepagamento VARCHAR(10) PRIMARY KEY NOT NULL,"
					+ " prezzotot INT(10) NOT NULL,"+"datapagamento VARCHAR(20) NOT NULL);";
			
		
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Table created successfully");
	}
	
	
	public static void main(String args[]) {
		 create();
		 insert();	
	}
}
