package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

//Codice per creazione e ripristino del Database. Tabella Spedizione.
public class Spedizione {
	public static void insert() {
		Connection c = null;
		Statement stmt = null;

		try {
			//Collegamento del JDBC con il DataBase SQLite.
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");

			//Statement per l'isenrimento delle tuple.
			stmt = c.createStatement();
			String sql = "INSERT OR REPLACE INTO Spedizione (Codicetracking,dataS,dataC)"
					+ "VALUES('123654753','29/11/2019','02/12/2019');";
			stmt.executeUpdate(sql);

			sql = "INSERT OR REPLACE INTO Spedizione (Codicetracking,dataS,dataC)" + "VALUES('357895448','12/12/2019','16/12/2019');";
			stmt.executeUpdate(sql);

			

			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Records created successfully");

	}

	public static void create() {
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			System.out.println("Opened database successfully");

			//Statement per rimozione e ricreazione della tabella.
			stmt = c.createStatement();
			
			String sql ="DROP TABLE Spedizione;"+"CREATE TABLE IF NOT EXISTS Spedizione " + "(Codicetracking VARCHAR(15) PRIMARY KEY NOT NULL,"
					+ " dataS VARCHAR(20) NOT NULL,"+"dataC VARCHAR(20) NOT NULL);";
			
		
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Table created successfully");
	}
	
	
	public static void main(String args[]) {
		 create();
		 insert();	
	}

}
