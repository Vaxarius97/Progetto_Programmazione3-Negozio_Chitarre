package Decorator_Pattern;
import Progetto.ListaOrdini;

//Classe che estende la classe Client che inizializza gli oggetti interessati.
public class Chitarradaimballare extends Client {
	
	public String Chitarradaimballare() {
		productName = null ;
		 return productName;
	}
	
	@Override
	public int getPrice() {
		return 0;
	}

}
