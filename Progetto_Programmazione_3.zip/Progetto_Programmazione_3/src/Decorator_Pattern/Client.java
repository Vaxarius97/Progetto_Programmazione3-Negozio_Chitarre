package Decorator_Pattern;

//Classe astratta per la dichiarazione del nome del prodotto da imballare e il costo dell'imballaggio. 
public abstract class Client {
	String productName = "";
	public String getProductName() {
		return productName;
	}
	public abstract int getPrice();

}
