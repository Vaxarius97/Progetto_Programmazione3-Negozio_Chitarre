package Decorator_Pattern;

//Test per verificare funzionamento del Decorator Pattern.
public class DecoratorPattern {
	public static void main(String[] args) {
		Client imballofinito= new ImballaggioChitarra(new Chitarradaimballare());
		System.out.println("Imballaggio della chitarra: "+ imballofinito.getProductName() + imballofinito.getPrice()+"�.");
	}
	
}
