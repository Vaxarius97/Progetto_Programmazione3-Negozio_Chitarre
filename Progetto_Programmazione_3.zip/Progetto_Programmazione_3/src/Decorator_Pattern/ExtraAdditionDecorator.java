package Decorator_Pattern;

public abstract class ExtraAdditionDecorator extends Client {
	protected Client client;
	@Override 
	public abstract String getProductName();

}
