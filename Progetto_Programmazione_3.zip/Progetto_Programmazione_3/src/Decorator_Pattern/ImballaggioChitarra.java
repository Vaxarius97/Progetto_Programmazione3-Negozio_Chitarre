package Decorator_Pattern;

//Classe utilizzata per dichiarare il Prodotto venduto con l'aggiunta del costo di imballaggio.
public class ImballaggioChitarra extends ExtraAdditionDecorator{
	public ImballaggioChitarra (Client client) {
		this.client = client;
	}
	
	@Override
	public String getProductName() {
		return client.getProductName() + " aggiunto imballaggio con costo di ";
	}

	@Override
	public int getPrice() {
		return client.getPrice() + 12;
	}

}
