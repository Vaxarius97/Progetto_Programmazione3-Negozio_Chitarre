package Observer_Pattern;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


public class Observabledelivery {
	private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyy HH:mm:ss");

	private String delivery;
	private List<Observer> observers = new ArrayList<>();
	
	public void addObserver(Observer observer) {
		observer.update(this.delivery);
		this.observers.add(observer);
	}
	
	public void removeObserver(Observer observer) {
		this.observers.remove(observer);
	}
	
	public Observabledelivery() {
		LocalDate localDate = LocalDate.now();
		this.delivery = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate) ;
		
	}
	
	public void setdelivery(String newDelivery) {
		this.delivery = newDelivery;
		for(Observer observer : this.observers) {
			observer.update(this.delivery);
		}
	}
	
	public String getdelivery() {
		return delivery;
	}
	
	public List<Observer> getObservers(){
		return observers;
	}
	
	public void setObservers(List<Observer> observers) {
		this.observers = observers;
	}


}
