package Observer_Pattern;

//Classe per aggiornare la data di acquisto del prodotto. 
public interface Observer {
	public void update(Object o);
}
