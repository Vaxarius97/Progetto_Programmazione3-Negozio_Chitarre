package Observer_Pattern;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

//Classe che permette di visionare e salvare nel DataBase il giorno di spedizione e di consegna.
public class ObserverDelivery implements Observer{
	private String dataconsegna;
	private String dataacquisto;
	public static String string;
	public static String string9;
	Connection c = null;
	Statement stmt = null;
	
	public ObserverDelivery(String data) {
		this.dataacquisto = data;
	}
	
	//Collegamento alla classe Observer per permettere l'aggiornamento della data di spedizione. 
	@Override
	public void update (Object dataconsegna) {
		System.out.println("La consegna dell'ordine effettuato il giorno: "+dataconsegna +" � prevista per il: "+ (String) dataacquisto);
		//Stringa di codice riferita alla Classe Tracking del package Progetto.
		string = "La consegna dell'ordine effettuato il giorno:"+dataconsegna +" � prevista il giorno:"+ (String) dataacquisto;
		//Stringa di codice riferita alla Classe RiepilogoUltimoOrdine del package Progetto.
		string9 = "Acquisto:"+dataconsegna +". Consegna: "+ (String) dataacquisto;
		//Generatore di numeri randomici per il codice della Spedizione nel DataBase. 
		int n = (int) (Math.random() * 999999999);
		try {
			//Collegamento del JDBC con il DataBase SQLite.
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");
			
			//Statement per l'isenrimento delle tuple.
			stmt = c.createStatement();
			String sql = "INSERT OR REPLACE INTO Spedizione (Codicetracking,dataS,dataC)" + "VALUES('"+n+"','"+dataconsegna+"','"+(String) dataacquisto+"');";
			stmt.executeUpdate(sql);
			

			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e1) {
			System.err.println(e1.getClass().getName() + ": " + e1.getMessage());
			System.exit(0);
		}
		System.out.println("Records created successfully");
		this.dataconsegna = (String) dataacquisto;
	}
	
	public String getdataconsegna() {
		return dataconsegna;
	}
	
	public void setdataconsegna(String dataconsegna) {
		this.dataconsegna = dataconsegna;
	}
	
	public String detdata() {
		return dataacquisto;
	}
	
	public void setdata(String data) {
		this.dataacquisto = data;
	}

}
