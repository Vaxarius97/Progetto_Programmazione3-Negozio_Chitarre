package Observer_Pattern;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

//Test per verificare funzionamento dell'Observer Pattern.
public class ObserverPattern {
	
	public static void main(String[] args) throws ParseException {
		LocalDate localDate = LocalDate.now();
		String dt = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate);  // Data Iniziale
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyy");
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, 4);  // numero dei giorni da aggiungere
		dt = sdf.format(c.getTime());  // la variabile dt � la nuova data con l'aggiunta dei giorni
		
		Observabledelivery deliv = new Observabledelivery();
		Observer observer1 = new ObserverDelivery(dt);
		
		
	
		deliv.addObserver(observer1);
		
		deliv.removeObserver(observer1);
		deliv.setdelivery(dt);
	}

	private static Object Observabledelivery() {
	
		return null;
	}

}
