package Progetto;
import Singleton_Pattern.*;
import Visitor_Pattern.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Progetto.SecondFrame;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;

public class Carrello {
	private JFrame frame;
	private JButton btnNewButton_1;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private int tasto;
	Connection cn;
    Statement st;
    ResultSet rs;
    String sql;
    public int totaleord;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Carrello window = new Carrello();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Carrello() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Visualizza");
		btnNewButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				
				
				List<Visitable> items = new ArrayList<>();
				
				//Singleton dedicato alla memorizzazione del prodotto scelto. 
				Singleton s1 = Singleton.factory();
				String string = s1.getMyString();
				
				//Singleton dedicato alla memorizzazione della quantit� del prodotto scelto. 
				Singleton s2 = Singleton.factory();
				int quantit� = s2.getMyInt();
				int prezzo = 0;
				
				//Singleton dedicato alla memorizzazione del carrello.
				Singleton s4 = Singleton.factory();
				String carrello = s4.getMyString4();
				
				//Richiamo del DataBase per conoscere il prezzo del prodotto scelto dal cliente. 
				try {
                    Class.forName("org.sqlite.JDBC");
                }
                catch (ClassNotFoundException f) {
                    System.out.println("ClassNotFoundException: ");
                    System.out.println(f.getMessage());
                }
                try {
                    cn = DriverManager.getConnection("jdbc:sqlite:test.db");
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }

                sql = "SELECT * FROM Chitarra where Marca='"+string+"';";

                try {
                    st = cn.createStatement();
                    rs = st.executeQuery(sql);
                    while (rs.next() == true) {
                             prezzo= rs.getInt("Prezzo");
                        }



                    }
                 catch (SQLException f) {
                    System.out.println("errore:"+ f.getMessage());
                }
                try {
                    cn.close();
                } catch (SQLException e1) {
                    
                    e1.printStackTrace();
                }
                
                //Esecuzione del Visitor Pattern.
                Oggetticostoquantit� o1 = new Oggetticostoquantit� (string,prezzo,quantit�);
                Oggetticostoquantit� o2 = new Oggetticostoquantit� ("Imballaggio chitarra",12,quantit�);
                
                items.add(o1);
				items.add(o2);
				int totalCost = calculateCost(items);
				System.out.println("Carrello dei prodotti: "+quantit�+" "+ string + " "+prezzo+"�"+ " + "+ " "+quantit�+" "+ o2.description()+" "+o2.prezzounitario()+"�"+ " = "+totalCost+ "�.");
				totaleord= totalCost;
				//Singleton dedicato alla memorizzazione del costo totale dell'ordine.
				Singleton s6 = Singleton.factory();
				int totalOrd = s6.getMyInt5();
				s6.setMyInt5(totaleord);
				if(tasto==0 && totaleord>0) {
					//Memorizzazione dei dati del carrello nella tabella Ordine del DataBase.
					lblNewLabel_1.setText(quantit�+" "+string + " "+prezzo*quantit�+"�"+ " + "+ " "+quantit�+" "+ o2.description()+" "+o2.prezzounitario()*quantit�+"�"+ "\n = "+totalCost+ "�.");
					carrello = quantit�+" "+string + " "+" = "+totalCost+ "�.";
					s4.setMyString4(carrello);
					
					Connection c = null;
					Statement stmt = null;
					//Generatore numeri randomici. 
					int n = (int) (Math.random() * 999);
					LocalDate localDate = LocalDate.now();
					String delivery = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate) ;
					try {
						Class.forName("org.sqlite.JDBC");
						c = DriverManager.getConnection("jdbc:sqlite:test.db");
						c.setAutoCommit(false);
						System.out.println("Opened database successfully");

						stmt = c.createStatement();
						String sql = "INSERT OR REPLACE INTO Ordine (Codiceordine,Prezzototale,Dataordine)"
								+ "VALUES("+n+","+prezzo*quantit�+",'"+delivery+"');";
						stmt.executeUpdate(sql);

						stmt.close();
						c.commit();
						c.close();
					} catch (Exception e1) {
						System.err.println(e1.getClass().getName() + ": " + e1.getMessage());
						System.exit(0);
					}
					tasto=1;
					
				}
				else {
					lblNewLabel_1.setText("Carrello vuoto.");
				}
				

                
			}
			private int calculateCost(List<Visitable> items) {
				int total = 0;
				Visitor visitor =  new ShoppingVisitor();
				
				for (Visitable item:items) {
					total = (int) (total+ item.accept(visitor));
					
				}
				return total;
				
			}
		});
		btnNewButton.setBounds(20, 192, 117, 38);
		frame.getContentPane().add(btnNewButton);
		
		btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBackground(Color.RED);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				SecondFrame view = new SecondFrame();
				SecondFrame.main(null);
			}
		});
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setBounds(0, 0, 85, 21);
		frame.getContentPane().add(btnNewButton_1);
		
		lblNewLabel = new JLabel("Carrello");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(176, 10, 126, 37);
		frame.getContentPane().add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(0, 71, 416, 111);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton_2 = new JButton("Acquista");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (totaleord>0) {
				JOptionPane.showMessageDialog(frame,"Grazie per il tuo acquisto.");
				Connection c = null;
				Statement stmt = null;
				int n = (int) (Math.random() * 999);
				LocalDate localDate = LocalDate.now();
				String delivery = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate) ;
				
				//Alla pressione del tasto acquista, i prodotti verranno pagati e aggiunti alla tabella Pagamento del DataBase.
				try {
					Class.forName("org.sqlite.JDBC");
					c = DriverManager.getConnection("jdbc:sqlite:test.db");
					c.setAutoCommit(false);
					System.out.println("Opened database successfully");

					stmt = c.createStatement();
				
					sql = "INSERT OR REPLACE INTO Pagamento (Codicepagamento,prezzotot,datapagamento)" + "VALUES('pag"+n+"',"+totaleord+",'"+delivery+"');";
					stmt.executeUpdate(sql);

					

					stmt.close();
					c.commit();
					c.close();
				} catch (Exception e1) {
					System.err.println(e1.getClass().getName() + ": " + e1.getMessage());
					System.exit(0);
				}
				System.out.println("Records created successfully");
				//Bottone che fa accedere alla classe ListaOrdini.
				frame.dispose();
				ListaOrdini view = new ListaOrdini();
				ListaOrdini.main(null);
			}
			else {
				JOptionPane.showMessageDialog(frame,"Aggiungi prodotti al carrello.");
			}
			}
		});
		btnNewButton_2.setBounds(299, 192, 117, 38);
		frame.getContentPane().add(btnNewButton_2);
	
	
	}

	protected Double calculateCost(List<Visitable> items) {
		return null;
	}
}
