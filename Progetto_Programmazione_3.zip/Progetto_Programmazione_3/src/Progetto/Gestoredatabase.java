package Progetto;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.List;
import java.sql.*;
public class Gestoredatabase {

	private JFrame frame;
	private List list;
	private int tasto;
	private int tasto2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gestoredatabase window = new Gestoredatabase();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Gestoredatabase() {
		initialize();
	}

	Connection cn;
	Statement st;
	ResultSet rs;
	String sql;
	private JTable table;
	private JTextField textField;
	
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 432, 319);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				frame.dispose();
				InterfacciaAdmin view = new InterfacciaAdmin();
				InterfacciaAdmin.main(null);
			
			}
		});
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Chitarra");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//bottone che ripulisce la tabella di stampa del database e la riscrive con le informazioni della tabbella Chitarra
				
				try {
					Class.forName("org.sqlite.JDBC");
				}
				catch (ClassNotFoundException f) {
					System.out.println("ClassNotFoundException: ");
					System.out.println(f.getMessage());	
				}
				try {
					cn = DriverManager.getConnection("jdbc:sqlite:test.db");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				sql = "SELECT * FROM Chitarra;";
				
				try {
					st = cn.createStatement();
					rs = st.executeQuery(sql);
					list.removeAll();
					while (rs.next() == true) {
			
							list.add(rs.getString("Marca")+"   "+rs.getInt("Seriale")+"   "+rs.getString("Tipo")+"   "+ rs.getInt("Prezzo")+"   "+rs.getString("Stato")+".");
						}
						
						
						
					}
				 catch (SQLException f) {
					System.out.println("errore:"+ f.getMessage());
				}
				try {
					cn.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
				
			}
		);
		btnNewButton_1.setBounds(293, 40, 114, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Ordine");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//bottone che ripulisce la tabella di stampa del database e la riscrive con le informazioni della tabbella Ordine
				
				try {
					Class.forName("org.sqlite.JDBC");
				}
				catch (ClassNotFoundException f) {
					System.out.println("ClassNotFoundException: ");
					System.out.println(f.getMessage());	
				}
				try {
					cn = DriverManager.getConnection("jdbc:sqlite:test.db");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				sql = "SELECT * FROM Ordine;";
				
				try {
					st = cn.createStatement();
					rs = st.executeQuery(sql);
					list.removeAll();
					while (rs.next() == true) {
				
							list.add(rs.getString("Codiceordine")+"   "+rs.getInt("Prezzototale")+"   "+rs.getString("Dataordine")+".");
							
						}
						
						
						
					}
				 catch (SQLException f) {
					System.out.println("errore:"+ f.getMessage());
				}
				try {
					cn.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_2.setBounds(293, 74, 114, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Pagamento");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//bottone che ripulisce la tabella di stampa del database e la riscrive con le informazioni della tabbella Pagamento
				
				try {
					Class.forName("org.sqlite.JDBC");
				}
				catch (ClassNotFoundException f) {
					System.out.println("ClassNotFoundException: ");
					System.out.println(f.getMessage());	
				}
				try {
					cn = DriverManager.getConnection("jdbc:sqlite:test.db");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				sql = "SELECT * FROM Pagamento;";
				
				try {
					st = cn.createStatement();
					rs = st.executeQuery(sql);
					list.removeAll();
					while (rs.next() == true) {
				
							list.add(rs.getString("Codicepagamento")+"   "+rs.getInt("Prezzotot")+"   "+rs.getString("Datapagamento")+".");
							
						}
						
						
						
					}
				 catch (SQLException f) {
					System.out.println("errore:"+ f.getMessage());
				}
				try {
					cn.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_3.setBounds(293, 108, 114, 23);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Recensione");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//bottone che ripulisce la tabella di stampa del database e la riscrive con le informazioni della tabbella Recensione
		
				
				try {
					Class.forName("org.sqlite.JDBC");
				}
				catch (ClassNotFoundException f) {
					System.out.println("ClassNotFoundException: ");
					System.out.println(f.getMessage());	
				}
				try {
					cn = DriverManager.getConnection("jdbc:sqlite:test.db");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				sql = "SELECT * FROM Recensione;";
				
				try {
					st = cn.createStatement();
					rs = st.executeQuery(sql);
					list.removeAll();
					while (rs.next() == true) {
				
							list.add(rs.getString("NumeroR")+"   "+rs.getString("valutazione")+".");
							
						}
						
						
						
					}
				 catch (SQLException f) {
					System.out.println("errore:"+ f.getMessage());
				}
				try {
					cn.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			
			}
		});
		btnNewButton_4.setBounds(293, 142, 114, 23);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Spedizione");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//bottone che ripulisce la tabella di stampa del database e la riscrive con le informazioni della tabbella Spedizione
		
				
				try {
					Class.forName("org.sqlite.JDBC");
				}
				catch (ClassNotFoundException f) {
					System.out.println("ClassNotFoundException: ");
					System.out.println(f.getMessage());	
				}
				try {
					cn = DriverManager.getConnection("jdbc:sqlite:test.db");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				sql = "SELECT * FROM Spedizione;";
				
				try {
					st = cn.createStatement();
					rs = st.executeQuery(sql);
					list.removeAll();
					while (rs.next() == true) {
				
							list.add(rs.getString("Codicetracking")+"   "+rs.getString("dataS")+"   "+rs.getString("DataC")+".");
							
						}
						
						
						
					}
				 catch (SQLException f) {
					System.out.println("errore:"+ f.getMessage());
				}
				try {
					cn.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_5.setBounds(293, 176, 114, 23);
		frame.getContentPane().add(btnNewButton_5);
		
		list = new List();
		list.setBounds(10, 40, 277, 236);
		frame.getContentPane().add(list);
	}
}
