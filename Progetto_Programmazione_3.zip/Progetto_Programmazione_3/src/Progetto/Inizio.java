package Progetto;

import DataBase.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import Progetto.LoginAdmin;
import Progetto.SecondFrame;

import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import java.awt.Component;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Inizio {

	private JFrame frame;
	

	/**
	 * Launch the application.
	 */
	
	//Comandi iniziali per la creazione all'avvio del DB
	public static void main(String[] args) {
		
			 create();
			 insert();	
			 create2();
			 insert2();	
			 create3();
			 insert3();	
			 create4();
			 insert4();	
			 create5();
			 insert5();
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inizio window = new Inizio();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Inizio() {
		initialize();
	}
	//Ordine DB
	public static void insert() {
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");

			stmt = c.createStatement();
			String sql = "INSERT OR REPLACE INTO Ordine (Codiceordine,Prezzototale,Dataordine)"
					+ "VALUES(101,600,'26/11/2019');";
			stmt.executeUpdate(sql);

			sql = "INSERT OR REPLACE INTO Ordine (Codiceordine,Prezzototale,Dataordine)" + "VALUES(102,900,'09/12/2019');";
			stmt.executeUpdate(sql);

			

			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Records created successfully");

	}

	public static void create() {
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			System.out.println("Opened database successfully");

			stmt = c.createStatement();
			
			String sql ="CREATE TABLE IF NOT EXISTS Ordine " + "(Codiceordine INT(3) PRIMARY KEY NOT NULL,"
					+ " Prezzototale INT(10) NOT NULL, " + " Dataordine VARCHAR(20) NOT NULL);";
			
		
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Table created successfully");
	}
	
	
	//Pagamento DB
	public static void insert2() {
		
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");

			stmt = c.createStatement();
			String sql = "INSERT OR REPLACE INTO Pagamento (Codicepagamento,prezzotot,datapagamento)"
					+ "VALUES('pag1',600,'27/11/2019');";
			stmt.executeUpdate(sql);

			sql = "INSERT OR REPLACE INTO Pagamento (Codicepagamento,prezzotot,datapagamento)" + "VALUES('pag2',900,'11/12/2019');";
			stmt.executeUpdate(sql);

			

			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Records created successfully");

	}

	public static void create2() {
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			System.out.println("Opened database successfully");

			stmt = c.createStatement();
			
			String sql ="CREATE TABLE IF NOT EXISTS Pagamento " + "(Codicepagamento VARCHAR(10) PRIMARY KEY NOT NULL,"
					+ " prezzotot INT(10) NOT NULL,"+"datapagamento VARCHAR(20) NOT NULL);";
			
		
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Table created successfully");
	}
	
	//Chitarra DB 
	public static void insert3() {
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");

			stmt = c.createStatement();
			String sql = "INSERT OR REPLACE INTO Chitarra (Marca,Seriale,Tipo,Prezzo,Stato) "
					+ "VALUES('Ibanez',1032564789,'Acustica',155,'Nuova');";
			stmt.executeUpdate(sql);

			sql = "INSERT OR REPLACE INTO Chitarra (Marca,Seriale,Tipo,Prezzo,Stato)" + "VALUES('Yamaha',2058963147,'Elettrica',270,'Nuova');";
			stmt.executeUpdate(sql);

			sql = "INSERT OR REPLACE INTO Chitarra (Marca,Seriale,Tipo,Prezzo,Stato) " + "VALUES('Fender',1023456789,'Classica',100,'Usata');";
			stmt.executeUpdate(sql);

			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Records created successfully");

	}

	public static void create3() {
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			System.out.println("Opened database successfully");

			stmt = c.createStatement();
			
			String sql ="CREATE TABLE IF NOT EXISTS Chitarra " + "(Marca VARCHAR(20) NOT NULL,"
					+ " Seriale INT(10) PRIMARY KEY NOT NULL, " + " Tipo VARCHAR(20) NOT NULL, "
					+ " Prezzo INT(10) NOT NULL, " + " Stato VARCHAR(20) NOT NULL);";
			
			
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Table created successfully");
	}
	
	//Recensione DB
	public static void insert4() {
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");

			stmt = c.createStatement();
			String sql = "INSERT OR REPLACE INTO Recensione (NumeroR,valutazione)"
					+ "VALUES('159874624','Positivo');";
			stmt.executeUpdate(sql);

			sql = "INSERT OR REPLACE INTO Recensione (NumeroR,valutazione)" + "VALUES('123456708','Negativo');";
			stmt.executeUpdate(sql);
			

			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Records created successfully");

	}

	public static void create4() {
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			System.out.println("Opened database successfully");

			stmt = c.createStatement();
			
			String sql ="CREATE TABLE IF NOT EXISTS  Recensione " + "(NumeroR INT(10) PRIMARY KEY NOT NULL,"
					+ " valutazione VARCHAR(10) NOT NULL);";
			
		
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Table created successfully");
	}
	
	//Spedizione DB
	
	public static void insert5() {
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");

			stmt = c.createStatement();
			String sql = "INSERT OR REPLACE INTO Spedizione (Codicetracking,dataS,dataC)"
					+ "VALUES('123654753','29/11/2019','02/12/2019');";
			stmt.executeUpdate(sql);

			sql = "INSERT OR REPLACE INTO Spedizione (Codicetracking,dataS,dataC)" + "VALUES('357895448','12/12/2019','16/12/2019');";
			stmt.executeUpdate(sql);

			

			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Records created successfully");

	}

	public static void create5() {
		Connection c = null;
		Statement stmt = null;

		try {
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:test.db");
			System.out.println("Opened database successfully");

			stmt = c.createStatement();
			
			String sql ="CREATE TABLE IF NOT EXISTS Spedizione " + "(Codicetracking VARCHAR(15) PRIMARY KEY NOT NULL,"
					+ " dataS VARCHAR(20) NOT NULL,"+"dataC VARCHAR(20) NOT NULL);";
			
		
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.exit(0);
		}
		System.out.println("Table created successfully");
	}
	
	
	
	
	
	
	
	
	
		
	

	
	
	
	
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 539, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Benvenuto in ShopChitarra");
		lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 20));
		lblNewLabel.setBounds(91, 10, 353, 55);
		frame.getContentPane().add(lblNewLabel);
		
		
		JLabel lblNewLabel_1 = new JLabel("Area clienti.");
		lblNewLabel_1.setBounds(63, 113, 68, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Area Amministrativa.");
		lblNewLabel_2.setBounds(377, 113, 131, 13);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Clienti");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Bottone che fa accedere alla classe SecondFrame
				frame.dispose();
				SecondFrame view = new SecondFrame();
				SecondFrame.main(null);
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(51, 153, 85, 47);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Admin");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Bottone che fa accedere alla classe LoginAdmin
				frame.dispose();
				LoginAdmin view = new LoginAdmin();
				LoginAdmin.main(null);
			}
		});
		btnNewButton_1.setBounds(394, 153, 85, 47);
		frame.getContentPane().add(btnNewButton_1);
	}
}
