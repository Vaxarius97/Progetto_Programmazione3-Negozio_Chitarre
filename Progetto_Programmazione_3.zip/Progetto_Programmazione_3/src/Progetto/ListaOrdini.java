package Progetto;
import Singleton_Pattern.*;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Progetto.Carrello;
import Progetto.SecondFrame;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;

public class ListaOrdini {
	private JFrame frame;
	private JButton btnNewButton_1;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_2;
	private JButton btnNewButton;
	private JButton btnTraking;
	Singleton s4 = Singleton.factory();
	String carrello = s4.getMyString4();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListaOrdini window = new ListaOrdini();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ListaOrdini() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBackground(Color.RED);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				SecondFrame view = new SecondFrame();
				SecondFrame.main(null);
			}
		});
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setBounds(0, 0, 85, 21);
		frame.getContentPane().add(btnNewButton_1);
		
		lblNewLabel = new JLabel("Lista Ordine");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(176, 10, 126, 37);
		frame.getContentPane().add(lblNewLabel);
		
		lblNewLabel_2 = new JLabel("Ordine Carrello");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel_2.setBounds(10, 62, 260, 48);
		frame.getContentPane().add(lblNewLabel_2);
		
		btnNewButton = new JButton("Recensione");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Bottone che fa accedere alla classe Recensisci.
				
				frame.dispose();
				Recensisci view = new Recensisci();
				Recensisci.main(null);
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(319, 106, 99, 37);
		frame.getContentPane().add(btnNewButton);
		
		btnTraking = new JButton("Tracking");
		btnTraking.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Bottone che fa accedere alla classe Tracking.
				frame.dispose();
				Tracking view = new Tracking();
				Tracking.main(null);
			}
		});
		btnTraking.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnTraking.setBounds(319, 181, 99, 37);
		frame.getContentPane().add(btnTraking);
		
		JLabel lblNewLabel_1 = new JLabel(carrello);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(20, 119, 250, 71);
		frame.getContentPane().add(lblNewLabel_1);
	}
}
