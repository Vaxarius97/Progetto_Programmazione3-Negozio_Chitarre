package Progetto;
import Proxy_Pattern.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;

import Progetto.Inizio;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPasswordField;

public class LoginAdmin {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginAdmin window = new LoginAdmin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginAdmin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login Admin");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setBounds(165, 11, 104, 33);
		frame.getContentPane().add(lblNewLabel);
		/*Bottone che esegue il Proxy pattern per la verifica dell'accesso 
		  e se password e utente sono corretti accede alla classe InterfacciaAdmin*/
		JButton btnNewButton = new JButton("Accedi");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String user = textField.getText();
				String psw = passwordField.getText();
				
				
				
				if( user.equals("admin") && psw.equals("admin") )
				{	
					Visualizza visualizza = new IDutente( "admin",  "admin");
		        	System.out.println( "login corretto: " + visualizza.utente("") );
					JOptionPane.showMessageDialog(frame, "Login eseguito con successo");
					frame.dispose();
					InterfacciaAdmin view = new InterfacciaAdmin();
					InterfacciaAdmin.main(null);
				}
				else
				{	Visualizza visualizza = new IDutente( "pippo",  "pluto");
			        System.out.println( "login errato: " + visualizza.utente("Error") );
					JOptionPane.showMessageDialog(frame, "Username o Password errati");
				}
				
			 
			    
				
				
			}
		});
		btnNewButton.setBounds(172, 227, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel_1.setBounds(10, 97, 104, 23);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel_2.setBounds(10, 155, 89, 23);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(108, 96, 316, 33);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Inizio view = new Inizio();
				Inizio.main(null);
			}
		});
		btnNewButton_1.setBackground(Color.RED);
		btnNewButton_1.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(109, 154, 315, 33);
		frame.getContentPane().add(passwordField);
	}
}
