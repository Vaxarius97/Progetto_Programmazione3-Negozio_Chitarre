package Progetto;
import java.lang.Math;
import java.util.Random;
import java.security.SecureRandom;
import Singleton_Pattern.Singleton;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import Progetto.SecondFrame;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Arrays;
import java.awt.event.ActionEvent;

public class Recensisci {

	private JFrame frame;
	public String valutazione;
	Singleton s3 = Singleton.factory();
	String string3 = s3.getMyString3();
	
	Singleton s4 = Singleton.factory();
	int voto = s4.getMyInt2();
	Singleton s6 = Singleton.factory();
	int totalOrd = s6.getMyInt5();
	Connection c = null;
	Statement stmt = null;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Recensisci window = new Recensisci();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Recensisci() {
		initialize();
	}
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frame.dispose();
				ListaOrdini view = new ListaOrdini();
				ListaOrdini.main(null);
				
			}
		});
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setBounds(0, 0, 85, 21);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Recensione");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setBounds(163, 10, 123, 29);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Valuti il tuo acquisto in maniera:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(109, 78, 216, 21);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("Negativa");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//Il bottone negativa permette di rencensire il prodotto acquistato in modo negativo e aggiorna la tabella Recensione del DataBase.
				if(totalOrd>0) {	
				if(voto == 0) {
					string3 = "Negativo";
					s3.setMyString3(string3);
					JOptionPane.showMessageDialog(frame,"La tua recensione � Negativa.");
					voto = 1;
					s4.setMyInt2(voto);
					int n = (int) (Math.random() * 999999999);
					try {
						Class.forName("org.sqlite.JDBC");
						c = DriverManager.getConnection("jdbc:sqlite:test.db");
						c.setAutoCommit(false);
						System.out.println("Opened database successfully");

						stmt = c.createStatement();
						String sql = "INSERT OR REPLACE INTO Recensione (NumeroR,valutazione)"
								+ "VALUES('"+n+"','"+string3+"');";
						stmt.executeUpdate(sql);
						

						stmt.close();
						c.commit();
						c.close();
					} catch (Exception e1) {
						System.err.println(e1.getClass().getName() + ": " + e1.getMessage());
						System.exit(0);
					}
					System.out.println("Records created successfully");
				}
				
				else {
					JOptionPane.showMessageDialog(frame, "Hai gi� valutato questo prodotto");
				}
			
				
				
		}
				else {
					JOptionPane.showMessageDialog(frame, "Non hai prodotti da recensire.");
				}
			}});
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setBounds(47, 139, 138, 67);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnPositivo = new JButton("Positiva");
		btnPositivo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Il bottone positiva permette di rencensire il prodotto acquistato in modo positivo e aggiorna la tabella Recensione del DataBase.
				if(totalOrd>0) {
				if(voto== 0) {
					string3 = "Positivo";
					s3.setMyString3(string3);
					JOptionPane.showMessageDialog(frame,"La tua recensione � Positiva.");
					voto = 1;
					s4.setMyInt2(voto);
					int n = (int) (Math.random() * 999999999);
					try {
						Class.forName("org.sqlite.JDBC");
						c = DriverManager.getConnection("jdbc:sqlite:test.db");
						c.setAutoCommit(false);
						System.out.println("Opened database successfully");

						stmt = c.createStatement();
						String sql = "INSERT OR REPLACE INTO Recensione (NumeroR,valutazione)"
								+ "VALUES('"+n+"','"+string3+"');";
						stmt.executeUpdate(sql);
						

						stmt.close();
						c.commit();
						c.close();
					} catch (Exception e1) {
						System.err.println(e1.getClass().getName() + ": " + e1.getMessage());
						System.exit(0);
					}
					System.out.println("Records created successfully");
				}
				
				else {
					JOptionPane.showMessageDialog(frame, "Hai gi� valutato questo prodotto");
				}
			
			}
				else{
					JOptionPane.showMessageDialog(frame, "Non hai prodotti da recensire.");}
				}
		});
		btnPositivo.setForeground(Color.GREEN);
		btnPositivo.setBounds(245, 139, 138, 67);
		frame.getContentPane().add(btnPositivo);
	}

}
