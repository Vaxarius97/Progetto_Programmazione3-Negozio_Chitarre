package Progetto;
import Visitor_Pattern.*;
import Singleton_Pattern.Singleton;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.awt.event.ActionEvent;

public class RiepilogoUltimoOrdine {

	private JFrame frame;
	Connection cn;
    Statement st;
    ResultSet rs;
    String sql;
    int tasto;
    public String valutazione;
    int voto;
    Singleton s3 = Singleton.factory();
	String string3 = s3.getMyString3();
	Singleton s5 = Singleton.factory();
	String data = s5.getMyString5();
	Singleton s6 = Singleton.factory();
	int totalOrd = s6.getMyInt5();
  
	
  
    

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RiepilogoUltimoOrdine window = new RiepilogoUltimoOrdine();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RiepilogoUltimoOrdine() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Riepilogo");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setBounds(169, 10, 140, 23);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				InterfacciaAdmin view = new InterfacciaAdmin();
				InterfacciaAdmin.main(null);
			}
		});
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setBounds(0, 0, 85, 21);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Ultimo Ordine:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(10, 72, 117, 23);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Data di consegna:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(10, 145, 140, 23);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Recensione:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(10, 218, 90, 23);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBounds(171, 72, 248, 23);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel label = new JLabel("");
		label.setBounds(177, 145, 242, 23);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(177, 218, 132, 23);
		frame.getContentPane().add(label_1);
		
		JButton btnNewButton_1 = new JButton("Visualizza");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*alla pressione del bottone immette nelle label tutte le informazioni dell'ultimo ordine effettuato dal cliente */
				
				List<Visitable> items = new ArrayList<>();
				
				Singleton s1 = Singleton.factory();
				String string = s1.getMyString();
				
				Singleton s2 = Singleton.factory();
				int quantit� = s2.getMyInt();
				int prezzo = 0;
				String Marca = "";
				
				if(tasto==0 && voto==0) {
					lblNewLabel_4 .setText("Chitarra: "+string+" costo: "+totalOrd+"� quantit�: "+quantit�);
					label.setText(data);
					label_1.setText(string3);
					tasto = 1;
					voto = 1;
					
				}
				
			
		}
			private int calculateCost(List<Visitable> items) {
				int total = 0;
				Visitor visitor =  new ShoppingVisitor();
				
				for (Visitable item:items) {
					total = (int) (total+ item.accept(visitor));
					
				}
				return total;
				
			}
			});
		btnNewButton_1.setBounds(319, 221, 100, 21);
		frame.getContentPane().add(btnNewButton_1);
	}
}
