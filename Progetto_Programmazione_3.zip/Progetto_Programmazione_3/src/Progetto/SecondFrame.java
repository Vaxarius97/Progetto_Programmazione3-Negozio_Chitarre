package Progetto;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

import Progetto.Carrello;
import Progetto.Inizio;
import Progetto.Recensisci;

import java.awt.FlowLayout;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

public class SecondFrame {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SecondFrame window = new SecondFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SecondFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btnNewButton = new JButton("Visualizza Prodotti");
		btnNewButton.setBounds(119, 91, 206, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Bottone che fa accedere alla classe VisualizzaProdotti.
				frame.dispose();
				try {
					VisualizzaProdotti view = new VisualizzaProdotti();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				VisualizzaProdotti.main(null);
				
			}
		});
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Lista Ordini");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Bottone che fa accedere alla classe ListaOrdini.
				frame.dispose();
				ListaOrdini view = new ListaOrdini();
				ListaOrdini.main(null);
			}
		});
		btnNewButton_1.setBounds(119, 125, 206, 23);
		frame.getContentPane().add(btnNewButton_1);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Carrello");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Bottone che fa accedere alla classe Carrello.
				frame.dispose();
				Carrello view = new Carrello();
				Carrello.main(null);
			}
		});
		btnNewButton_2.setBounds(119, 159, 206, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("CLIENTE");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setBounds(178, 11, 78, 38);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton_5 = new JButton("Back");
		btnNewButton_5.setBackground(Color.RED);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frame.dispose();
				Inizio view = new Inizio();
				Inizio.main(null);
			}
		});
		btnNewButton_5.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(btnNewButton_5);
	}
}
