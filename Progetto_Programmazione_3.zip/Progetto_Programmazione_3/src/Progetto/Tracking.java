package Progetto;
import java.lang.Math;
import java.util.Random;
import java.security.SecureRandom;
import Observer_Pattern.*;
import Singleton_Pattern.Singleton;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.awt.event.ActionEvent;
import java.awt.Color;
import DataBase.*;

public class Tracking {

	private JFrame frame;
	
	
	Singleton s5 = Singleton.factory();
	String data = s5.getMyString5();
	Singleton s6 = Singleton.factory();
	int totalOrd = s6.getMyInt5();
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tracking window = new Tracking();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Tracking() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 507, 368);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
	
		
		
		
		
		JLabel lblNewLabel = new JLabel("Tracking");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setBounds(210, 10, 109, 23);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(0, 68, 503, 166);
		frame.getContentPane().add(lblNewLabel_1);
		
		
		
		
		JButton btnNewButton = new JButton("Traccia il pacco");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Cliccando il bottone Traccia il pacco, si esegue l'Observer Pattern.
				if(totalOrd>0) {
				LocalDate localDate = LocalDate.now();
				String localDate1= DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate);
				String dt = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate); 
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyy");
				Calendar c = Calendar.getInstance();
				c.add(Calendar.DATE, 4); 
				dt = sdf.format(c.getTime());  
				
				Observabledelivery deliv = new Observabledelivery();
				Observer observer1 = new ObserverDelivery(dt);
				
				
			
				deliv.addObserver(observer1);
				
				deliv.removeObserver(observer1);
				deliv.setdelivery(dt);
					lblNewLabel_1.setText(ObserverDelivery.string);
					
					data = ObserverDelivery.string9;
					s5.setMyString5(data);	
				
				}
				else {
					JOptionPane.showMessageDialog(frame,"Prodotti da spedire inesistenti.");
				}
				
			
			}}
			
			
		);
		btnNewButton.setBounds(331, 289, 152, 32);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				ListaOrdini view = new ListaOrdini();
				ListaOrdini.main(null);
			}
		});
		btnNewButton_1.setBackground(Color.RED);
		btnNewButton_1.setBounds(0, 0, 85, 21);
		frame.getContentPane().add(btnNewButton_1);
	}
}
