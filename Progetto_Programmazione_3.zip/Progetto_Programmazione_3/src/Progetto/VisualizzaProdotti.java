package Progetto;
import Prototype_Pattern.*;
import Decorator_Pattern.*;
import Singleton_Pattern.*;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.sql.*;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.table.DefaultTableModel;
import java.awt.Button;
import java.awt.List;
import java.awt.Cursor;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;


public class VisualizzaProdotti{
	private JFrame frame;
	private List list;
	private JTable table1;
	String numero = "";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VisualizzaProdotti window = new VisualizzaProdotti();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 */
	public VisualizzaProdotti() throws SQLException {
		initialize();
	}
	Connection cn;
	Statement st;
	ResultSet rs;
	String sql;
	private JTable table;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Initialize the contents of the frame.
	 * @throws SQLException 
	 */
	private void initialize() throws SQLException {
		
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Chitarre disponibili:");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Accesso al Database e scrittura su tabella delle chitarre disponibili nel negozio.
				try {
					Class.forName("org.sqlite.JDBC");
				}
				catch (ClassNotFoundException f) {
					System.out.println("ClassNotFoundException: ");
					System.out.println(f.getMessage());	
				}
				try {
					cn = DriverManager.getConnection("jdbc:sqlite:test.db");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				sql = "SELECT * FROM Chitarra;";
				
				try {
					list.removeAll();
					st = cn.createStatement();
					rs = st.executeQuery(sql);
					while (rs.next() == true ) {
							list.add(rs.getString("Marca")+"   "+rs.getInt("Seriale")+"   "+rs.getString("Tipo")+"   "+ rs.getInt("Prezzo")+"   "+rs.getString("Stato")+".");
							
						}
						
						
						
					}
				 catch (SQLException f) {
					System.out.println("errore:"+ f.getMessage());
				}
				try {
					cn.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(10, 52, 155, 23);
		frame.getContentPane().add(btnNewButton);
		
		list = new List();
		list.setBackground(new Color(255, 255, 255));
		list.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		list.setBounds(10, 81, 262, 51);
		frame.getContentPane().add(list);
		
		JLabel lblNewLabel = new JLabel("Visualizza Prodotti");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setBounds(163, 10, 174, 23);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Materiali:");
		lblNewLabel_1.setBounds(339, 52, 61, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("Yamaha");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//esegue il prototype_pattern collegato alla chitarra Yamaha segnalando il suo materiale(in questo caso Acero)
				
					Prototipomateriali client=new Prototipomateriali();
					
				client.popolaMap();
				//Yamaha
				Prototipochitarra Acero=client.getmarca(MaterialeChitarra.ACERO);
				System.out.println("la chitarra "+Acero.marca+" � composta dal materiale "+MaterialeChitarra.ACERO+".");
				JOptionPane.showMessageDialog(frame,"La chitarra "+Acero.marca+" � composta dal materiale "+MaterialeChitarra.ACERO+".");
		
				
				
				
			}
		});
		btnNewButton_1.setBounds(315, 74, 85, 21);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Ibanez");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//esegue il prototype_pattern collegato alla chitarra Ibanez segnalando il suo materiale(in questo caso Abete)
				
					Prototipomateriali client=new Prototipomateriali();
					
				client.popolaMap();
			
				Prototipochitarra Abete=client.getmarca(MaterialeChitarra.ABETE);
				System.out.println("La chitarra "+Abete.marca+" � composta dal materiale "+MaterialeChitarra.ABETE +".");
				JOptionPane.showMessageDialog(frame,"La chitarra "+Abete.marca+" � composta dal materiale "+MaterialeChitarra.ABETE +".");
				
				
			}
		});
		btnNewButton_2.setBounds(315, 105, 85, 21);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Fender");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//esegue il prototype_pattern collegato alla chitarra Fender segnalando il suo materiale(in questo caso Ebano)
				Prototipomateriali client=new Prototipomateriali();
				
				client.popolaMap();
				//Fender
				Prototipochitarra Ebano=client.getmarca(MaterialeChitarra.EBANO);
				System.out.println("la chitarra "+Ebano.marca+" � composta dal materiale "+MaterialeChitarra.EBANO+".");
				JOptionPane.showMessageDialog(frame,"La chitarra "+Ebano.marca+" � composta dal materiale "+MaterialeChitarra.EBANO+".");
			}
		});
		btnNewButton_3.setBounds(315, 136, 85, 21);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Conferma");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// //Bottone che permette di creare l'ordine dei prodotti desiderati.
				String productName = textField.getText();//Textfield dedicata al nome del prodotto.
				String numero = textField_1.getText();// Textfield dedicata alla quantit� dei prodotti. 
				
				
				
				if(productName.equals("") || numero.equals("")) {
					
					JOptionPane.showMessageDialog(frame, "Inserischi chitarra da acquistare o inserisci quantit�.");
					
					
				} else if(productName.equals("Yamaha") || productName.equals("Ibanez") || productName.equals("Fender")){
					int intero = Integer.parseInt(numero);
					if(intero<=3 && intero>0) {
						//Esecuzione del Decorator Pattern per l'imballaggio del/dei prodotto/prodotti.
						productName = textField.getText();
						Client imballofinito= new ImballaggioChitarra(new Chitarradaimballare());
						
						Singleton s1 = Singleton.factory();
						s1.setMyString(productName);
						
						Singleton s2 = Singleton.factory();
						s2.setMyInt(intero);
						
						JOptionPane.showMessageDialog(frame,"Imballaggio della chitarra: "+ intero + " "+productName +" "+ imballofinito.getPrice()*intero+"�.");
						System.out.println("Records created successfully");
						
						
						//Accesso alla classe Carrello.
						frame.dispose();
						Carrello view = new Carrello();
						Carrello.main(null);
						
						
					}
					else {
						
						JOptionPane.showMessageDialog(frame, "Quantit� non disponibile." );
						
					}
					
					
				} else {
					
					JOptionPane.showMessageDialog(frame, "Nome Errato o Chitarra non Disponibile" );
					
				}
			}
			
		});
		btnNewButton_4.setBounds(308, 219, 92, 21);
		frame.getContentPane().add(btnNewButton_4);
		
		textField = new JTextField();
		textField.setBounds(10, 214, 155, 32);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Acquista:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(10, 180, 85, 23);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton_5 = new JButton("Back");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				SecondFrame view = new SecondFrame();
				SecondFrame.main(null);
			}
		});
		btnNewButton_5.setBackground(Color.RED);
		btnNewButton_5.setBounds(0, 0, 85, 21);
		frame.getContentPane().add(btnNewButton_5);
		
		textField_1 = new JTextField();
		textField_1.setBounds(185, 214, 52, 32);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Quantit\u00E0:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(185, 187, 87, 13);
		frame.getContentPane().add(lblNewLabel_3);
	}
}
