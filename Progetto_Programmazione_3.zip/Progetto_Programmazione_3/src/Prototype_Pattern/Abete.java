package Prototype_Pattern;
//classse che include la marca di chitarra costituita dal materiale Abete
public class Abete extends Prototipochitarra{
public Abete(String marca) {
	super(marca);
}
@Override
public void stampamodello() {
	System.out.println(marca);
}
}