package Prototype_Pattern;
//classse che include la marca di chitarra costituita dal materiale Acero

public  class Acero extends Prototipochitarra{
public Acero(String marca) {
	super(marca);
}
@Override
public void stampamodello() {
	System.out.println(marca);
}
}