package Prototype_Pattern;
//classse che include la marca di chitarra costituita dal materiale Ebano


public class Ebano extends Prototipochitarra{
public Ebano(String marca) {
	super(marca);
}
@Override
public void stampamodello() {
	System.out.println(marca);
}

}
