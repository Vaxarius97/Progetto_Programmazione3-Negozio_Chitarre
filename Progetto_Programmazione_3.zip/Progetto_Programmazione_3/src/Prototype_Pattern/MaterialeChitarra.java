package Prototype_Pattern;

//enum con i possibili valori dei materiali del pattern

public enum MaterialeChitarra {
EBANO,ACERO,ABETE
}
