package Prototype_Pattern;
//classe astratta che crea un prototipo della chitarra basata sulla marca della stessa
public abstract class Prototipochitarra implements Cloneable {
public String marca;
public Prototipochitarra(String marca) {
	this.marca = marca;
}
public String getmarca() {
	return marca;
}
public void setmarca(String marca) {
	this.marca = marca;
}
public abstract void stampamodello ();
}
