package Prototype_Pattern;

import java.util.HashMap;
import java.util.Map;
// classe che genera i possibili prototipi di materiali disponibili a seconda della marca scelta
public class Prototipomateriali {
private Map<Enum,Prototipochitarra> chitarre = new HashMap<>();

public Prototipochitarra getmarca(MaterialeChitarra marca) {
	Prototipochitarra chitarra=chitarre.get(marca);
	if(chitarra==null) {
		return null;
	}
	//return chitarra.clone();
	return chitarra;
}
public void popolaMap() {
	chitarre.put(MaterialeChitarra.ABETE, new Abete("Ibanez"));
	chitarre.put(MaterialeChitarra.ACERO, new Acero("Yamaha"));
	chitarre.put(MaterialeChitarra.EBANO, new Ebano("Fender"));
}
}
