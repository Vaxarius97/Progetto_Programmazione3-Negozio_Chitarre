package Prototype_Pattern;
//Test per verificare funzionamento del Prototype Pattern.
public class PrototypePattern {
	public static void main(String[] args) {
		Prototipomateriali client=new Prototipomateriali();
		
	client.popolaMap();
	//caso di prototipo di oggetto composta dal materiale abete
	Prototipochitarra Abete=client.getmarca(MaterialeChitarra.ABETE);
	System.out.println("La chitarra "+Abete.marca+" � composta dal materiale "+MaterialeChitarra.ABETE +".");
	}
	
}