package Proxy_Pattern;

import java.util.ArrayList;
import java.util.List;
 
//Classe che estrae la classe e ritornare una lista vuota.
public class Estrattore {
 
    public static List getMovimenti(String utenti) {
        return new ArrayList();
    }
 
}