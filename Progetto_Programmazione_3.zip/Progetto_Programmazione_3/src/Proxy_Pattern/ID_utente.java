package Proxy_Pattern;

import java.util.List;

//Classe che implementa la Classe Visualizza, che permette di visionare la lista degli utenti estratti. 
public class ID_utente implements Visualizza {
 
    @Override
    public List utente(String utenti) {
        return Estrattore.getMovimenti(utenti);
    }
 
}