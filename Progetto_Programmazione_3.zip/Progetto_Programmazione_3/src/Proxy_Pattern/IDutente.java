package Proxy_Pattern;

import java.util.List;

//Classe che inizializza username e password e implementa la classe Visualizza per controllare i dati dell'utente.
public class IDutente implements Visualizza {
    private String username;
    private String password;
    private ID_utente id_ute;
    
    public IDutente(String username, String password){
        this.username = username;
        this.password = password;
        id_ute = new ID_utente();  
    }

    //Collegamento alla Classe Visualizza
    @Override
   public List utente(String utenti) {
       List lista = null;
       if( checkUser() )
           lista = id_ute.utente(utenti);
       
	return lista;
   }
    
   //Controllo dell'uguaglianza tra username e password.
   private boolean checkUser(){
       return IdentityManager.checkUser(username, password);
   }
    
}
