package Proxy_Pattern;

//Classe che inizializza il controllo dell'accesso utente.
public class IdentityManager {
	 
    public static boolean checkUser(String username, String password) {
        return (username.equals(password)) ? true : false;
    }
 
}