package Proxy_Pattern;

import java.util.ArrayList;

//Test per verificare funzionamento del Proxy Pattern. 
public class ProxyPattern {
	 
    public static void main(String[] args) {
        Visualizza visualizza = new IDutente( "pippo",  "pluto");
        System.out.println( "login errato: " + visualizza.utente("Error") );
 
        visualizza = new IDutente( "admin",  "admin");
        System.out.println( "login corretto: " + visualizza.utente("") );
        
      
    }
}
