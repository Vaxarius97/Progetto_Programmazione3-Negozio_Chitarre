package Proxy_Pattern;

import java.util.List;

//Interfaccia utilizzata per visualizzare lista degli utenti.
public interface Visualizza {
	
	List utente(String utenti);
}
