package Singleton_Pattern;
//Singleton utilizzato come memoria temporanea per conservare le informazioni dell'istanza. 
public class Singleton{
	
	private String mystring;//Prodotto scelto
	private String mystring3;//Recensione del prodotto
	private int myint;//Quantit� prodotto scelto
	private int myint2;// Visualizza se gi� � stato recensito il prodotto
	private String mystring4;//Memorizzazione Carrello
	private String mystring5;//Data ordine
	private int myint5;//Memorizzazione costo totale ordine

/*
Questa sara' l'unica istanza di questa classe.
Ogni accesso avverr� tramite quest oggetto
e non ne verranno creati altri.
*/
private static Singleton instance = null; 
/*
Costruttore privato per evitare la creazione di altre
istanze dell'oggetto
*/
private Singleton(){
}
/*
Unico punto di accesso all'istanza
*/
public static Singleton factory(){
//creo l'oggetto se non esiste
if(instance==null)
instance = new Singleton();
return instance;
}
public void setMyInt(int myint) {
	this.myint = myint;
}

public void setMyInt2(int myint2) {
	this.myint2 = myint2;
}

public void setMyInt5(int myint5) {
	this.myint5 = myint5;
}


public void setMyString(String mystring) {
    this.mystring = mystring;
}
public void setMyString3(String mystring3) {
	this.mystring3 = mystring3;
	
}
public void setMyString4(String mystring4) {
	this.mystring4 = mystring4;
	
}

public void setMyString5(String mystring5) {
	this.mystring5 = mystring5;
	
}


public int getMyInt() {
	return myint;
}

public int getMyInt2() {
	return myint2;
}

public int getMyInt5() {
	return myint5;
}


public String getMyString() {
    return mystring;
 }
public String getMyString3() {
    return mystring3;
 }

public String getMyString4() {
    return mystring4;
 }

public String getMyString5() {
    return mystring5;
 }

}