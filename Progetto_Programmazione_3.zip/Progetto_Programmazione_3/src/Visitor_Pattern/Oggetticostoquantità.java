package Visitor_Pattern;

public  class Oggetticostoquantit�  implements Visitable{
	
	//Dichiarazione del nome dei prodotti, del costo e della quantit�.
	private String description;
	private int prezzounitario;
	Integer numeropezzi;
	
	public Oggetticostoquantit�() {
		
	}
	
	public Oggetticostoquantit�( String description, int prezzo, Integer numeropezzi) {
		this.prezzounitario = prezzo;
		this.numeropezzi = numeropezzi;
		this.description = description;
	}
	
	public String description() {
		return description;
	}
	public int prezzounitario() {
		return prezzounitario;
	}
	
	//Richiamo alla classe Visitable.
	@Override 
	public Double accept (Visitor visitor) {
		return visitor.visit(this);
	}

	public double getprezzounitario() {
		
		return prezzounitario;
	}

	public int getnumeropezzi() {
		return numeropezzi;
	}

	

}
