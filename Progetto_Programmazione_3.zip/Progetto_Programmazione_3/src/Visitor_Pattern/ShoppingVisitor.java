package Visitor_Pattern;

/*Classe che implementa Visitor e permette di ricevere i dati degli oggetti con l'espressione matematica:
 numeropezzi*prezzounitario. Ci� sta ad indicare che svolge il prodotto tra la quantit� di oggetti acquistata e il loro prezzo.*/
public class ShoppingVisitor implements Visitor{
	@Override
	public Double visit(Oggetticostoquantit� item) {
		return 
	item.getnumeropezzi()*
	item.getprezzounitario();
	}

}
