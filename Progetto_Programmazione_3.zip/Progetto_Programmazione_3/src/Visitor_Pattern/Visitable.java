package Visitor_Pattern;

//Interfaccia di comunicazione con la classe Oggetticostoquantit�. 
public interface Visitable {
	Double accept(Visitor visitor);

}
