package Visitor_Pattern;

//Interfaccia collegata a ShoppingVisitor per permettere il prodotto tra due oggetti della classe Oggetticostoquantit�.
public interface Visitor {
	Double visit(Oggetticostoquantit� item);

}
