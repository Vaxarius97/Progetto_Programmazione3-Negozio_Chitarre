package Visitor_Pattern;

import java.util.ArrayList;
import java.util.List;

//Test per verificare funzionamento del Visitor Pattern. 
public class VisitorPattern {
	public static void main(String[] args) {
		
		List<Visitable> items = new ArrayList<>();
		Oggetticostoquantit� o1 = new Oggetticostoquantit� ("Yamaha",189,1);
		Oggetticostoquantit� o2 = new Oggetticostoquantit� ("Imballaggio chitarra",12,1);
		
		
		items.add(o1);
		items.add(o2);
		
		Double totalCost = calculateCost(items);
		System.out.println("Carrello dei prodotti: "+ o1.description()+ " "+o1.prezzounitario()+"�"+ " + "+ o2.description()+" "+o2.prezzounitario()+"�"+ " = "+totalCost+ "�.");
		
	}

	private static Double calculateCost(List<Visitable> items) {
		Double total = 0.0;
		Visitor visitor =  new ShoppingVisitor();
		
		for (Visitable item:items) {
			total = total + item.accept(visitor);
			
		}
		return total;
		
	}
}
