module proggg {
	requires java.sql;
	requires java.desktop;
	requires java.base;
	
	//requires commons.dbutils;
}